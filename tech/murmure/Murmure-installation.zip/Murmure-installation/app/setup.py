"""Build du bundle Murmure.app (py2app, mode alias).

Mode alias : crée un vrai lanceur natif Mach-O DANS le bundle (macOS voit donc
"Murmure" et non "python3.11"), tout en réutilisant le venv existant au lieu de
tout recopier. Léger.

Build :  ./venv/bin/python3 setup.py py2app -A
Puis signature ad-hoc :  codesign --force --deep --sign - dist/Murmure.app
"""
from setuptools import setup

APP = ["app.py"]

PLIST = {
    "CFBundleName": "Murmure",
    "CFBundleDisplayName": "Murmure",
    "CFBundleIdentifier": "com.mardoukhaev.murmure",
    "CFBundleShortVersionString": "1.0",
    "CFBundleVersion": "1",
    "LSMinimumSystemVersion": "11.0",
    "NSHighResolutionCapable": True,
    "NSMicrophoneUsageDescription":
        "Murmure utilise le micro pour transcrire votre voix en texte, en local.",
}

OPTIONS = {
    "iconfile": "Murmure.icns",
    "plist": PLIST,
    "argv_emulation": False,
}

setup(
    app=APP,
    name="Murmure",
    options={"py2app": OPTIONS},
    setup_requires=["py2app"],
)
