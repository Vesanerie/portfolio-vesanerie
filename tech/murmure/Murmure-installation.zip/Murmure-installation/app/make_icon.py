#!/usr/bin/env python3
"""Génère l'icône de Murmure en natif AppKit (squircle + onde vocale)."""
import math
from AppKit import (
    NSImage, NSBitmapImageRep, NSBezierPath, NSColor, NSGradient,
    NSBitmapImageFileTypePNG, NSCompositingOperationSourceOver,
    NSShadow, NSGraphicsContext,
)
from Foundation import NSMakeRect, NSMakePoint, NSMakeSize

S = 1024.0


def color(r, g, b, a=1.0):
    return NSColor.colorWithCalibratedRed_green_blue_alpha_(r/255, g/255, b/255, a)


def rounded_rect(x, y, w, h, radius):
    return NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(
        NSMakeRect(x, y, w, h), radius, radius)


def make():
    rep = NSBitmapImageRep.alloc().initWithBitmapDataPlanes_pixelsWide_pixelsHigh_bitsPerSample_samplesPerPixel_hasAlpha_isPlanar_colorSpaceName_bitmapFormat_bytesPerRow_bitsPerPixel_(
        None, int(S), int(S), 8, 4, True, False, "NSCalibratedRGBColorSpace", 0, 0, 0)
    ctx = NSGraphicsContext.graphicsContextWithBitmapImageRep_(rep)
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.setCurrentContext_(ctx)

    # Marge type macOS (l'icône ne remplit pas tout le canvas)
    inset = S * 0.09
    side = S - inset * 2
    radius = side * 0.2237  # superellipse Apple approx

    squircle = rounded_rect(inset, inset, side, side, radius)

    # Ombre portée douce
    shadow = NSShadow.alloc().init()
    shadow.setShadowBlurRadius_(36)
    shadow.setShadowOffset_(NSMakeSize(0, -18))
    shadow.setShadowColor_(NSColor.colorWithCalibratedWhite_alpha_(0, 0.35))
    shadow.set()

    # Fond : dégradé graphite quasi-noir, haut plus clair
    grad = NSGradient.alloc().initWithColors_([
        color(58, 58, 62),
        color(28, 28, 30),
        color(18, 18, 20),
    ])
    grad.drawInBezierPath_angle_(squircle, -90.0)

    # Coupe le dessin à l'intérieur du squircle pour les éléments suivants
    NSGraphicsContext.saveGraphicsState()
    squircle.addClip()

    # Liseré intérieur lumineux (effet verre macOS)
    NSShadow.alloc().init().set()  # reset shadow
    border = rounded_rect(inset + 2, inset + 2, side - 4, side - 4, radius - 2)
    border.setLineWidth_(3)
    color(255, 255, 255, 0.10).set()
    border.stroke()

    # Halo radial discret derrière l'onde
    halo = NSGradient.alloc().initWithColors_([
        color(255, 255, 255, 0.08),
        color(255, 255, 255, 0.0),
    ])
    cx, cy = S/2, S/2
    halo.drawInBezierPath_relativeCenterPosition_(
        rounded_rect(cx-300, cy-300, 600, 600, 300), NSMakePoint(0, 0))

    # Onde vocale : barres arrondies, hauteurs en cloche
    heights = [0.16, 0.34, 0.58, 0.82, 1.0, 0.82, 0.58, 0.34, 0.16]
    n = len(heights)
    bar_w = S * 0.052
    gap = S * 0.038
    total = n * bar_w + (n - 1) * gap
    x0 = cx - total / 2
    max_h = S * 0.46
    ink = color(244, 243, 236)  # blanc cassé chaud

    for i, hfrac in enumerate(heights):
        h = max_h * hfrac
        x = x0 + i * (bar_w + gap)
        bar = rounded_rect(x, cy - h/2, bar_w, h, bar_w/2)
        ink.set()
        bar.fill()

    NSGraphicsContext.restoreGraphicsState()
    NSGraphicsContext.restoreGraphicsState()

    data = rep.representationUsingType_properties_(NSBitmapImageFileTypePNG, {})
    data.writeToFile_atomically_("icon_1024.png", True)
    print("icon_1024.png écrit")


if __name__ == "__main__":
    make()
