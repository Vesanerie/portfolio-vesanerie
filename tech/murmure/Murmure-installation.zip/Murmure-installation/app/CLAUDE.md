# mur-mur (Murmure) — Playbook Claude

App de dictée vocale locale macOS via Whisper. Menu bar + fenêtre native + icône dock. Raccourci clavier global (Option droite ou F5). Texte transcrit auto-collé dans l'app active.

## Emplacement (IMPORTANT)

Le projet vit dans **`~/Library/Application Support/Murmure/`** (PLUS sur le Bureau).
Raison : une app lancée par macOS (launchd) n'a pas accès au dossier Bureau (protection vie privée TCC), et le venv doit être lisible. Application Support n'est pas protégé.

Le bundle double-cliquable est dans **`/Applications/Murmure.app`** (mode alias py2app : un lanceur natif signé qui réutilise ce venv).

## Stack

- Python 3, **venv local** `venv/` (sounddevice, pyperclip, rumps, pyobjc, faster_whisper, numpy)
- **Faster-Whisper** `large-v3-turbo` par défaut (switchable small/medium/turbo via `MODELS`), français, 100% local CPU, `local_files_only=True`. Turbo = plus rapide ET plus précis que medium sur M1 Pro (benchmark 13 juin)
- Menu bar + fenêtre via **rumps + AppKit (pyobjc)**
- **Hotkey global via NSEvent natif** (PLUS pynput, voir Pièges)
- **Collage/copie/undo via CGEvent natif (Quartz)** (PLUS osascript, voir Pièges)
- App au premier plan via **NSWorkspace** (PLUS osascript)
- Bundle via **py2app** (mode alias) + signature ad-hoc

## Architecture

```
Murmure/
├── app.py              # App principale (rumps + fenêtre AppKit)
├── setup.py            # Recette py2app (build du bundle)
├── make_icon.py        # Génère l'icône (onde vocale façon AM) en AppKit natif
├── icon_1024.png       # Source de l'icône
├── Murmure.icns        # Icône compilée (multi-résolutions)
├── run.sh / mur-mur.command  # Lancement direct ./venv/bin/python3 app.py
├── audio-switch.sh     # Hook BlackHole (lancé par la LaunchAgent, NE PAS casser)
├── dictionnaire.txt    # Vocabulaire custom (initial_prompt Whisper)
├── corrections.txt     # Find/replace post-transcription (format: wrong -> right)
└── venv/               # Environnement Python (gitignored)
```

## Réglages persistants

`config.json` (gitignored, dans le dossier projet) sauvegarde **modèle, langue, micro, mode média**. Chargé au démarrage (`load_config`), réécrit à chaque changement (`save_settings`). Valeurs invalides → défauts. **Défauts : turbo, fr, micro MacBook, média = mute.**

## Comportement

- **Option droite (kc 61) maintenue, ou F5 (kc 96)** → enregistre audio
- **Relâche** → Whisper transcrit → clipboard → Cmd+V auto (CGEvent) dans l'app active
- **Double tap Option droite** (<0.5s) → undo dernière dictée
- **Cmd+Shift+D** → ajoute la sélection au dictionnaire
- **Langue** : menu « Langue: fr/en/auto » cliquable (cycle). `force_language` + `LANGUAGES`. Le prompt du dico s'adapte à la langue.
- **Gestion média pendant la dictée** (`media_mode`, menu cliquable qui cycle `MEDIA_MODES` = auto/pause/mute/off, défaut auto). Empêche le micro de capter le son ambiant :
  - **pause** : `media_play_pause()` (touche système NSSystemDefined). Garde la place, mais une seule app (le « Now Playing »).
  - **mute** : `set_muted(True)` (osascript `set volume output muted`, pas de permission). Universel, coupe tout, mais le média avance.
  - **auto** : `count_audio_sources()` (compte les assertions coreaudiod `context.preventuseridlesleep`, 1 PAR flux audio actif) → 1 source = pause, ≥2 = mute.
  - Ne fait rien si `audio_is_playing()` est faux (n'éveille pas une vidéo déjà en pause). `_media_action` mémorise pause/mute pour l'annuler au relâchement.
  - Limites : grace period macOS ~1s sur l'assertion ; le comptage de sources est best-effort (Spotify ne déclare pas « Playing audio », d'où le comptage via coreaudiod). AEC tentée et échouée en local (filtre adaptatif + suppression spectrale) : on empêche l'écho au lieu de l'effacer.
- **Menu / fenêtre** : bouton pause écoute, switch modèle small/medium, recharger dico

## Pièges (lus dans le sang le 13 juin 2026)

- **JAMAIS pynput.** pynput interrogeait une API clavier macOS (TSMGetInputSourceProperty) depuis un thread secondaire → SIGTRAP / crash aléatoire sur macOS récent (Darwin 25). Remplacé par `NSEvent.addGlobalMonitor/addLocalMonitor` installés **sur le thread principal** (depuis `sync_window`, pas depuis le thread `_init`).
- **JAMAIS osascript/System Events** pour coller/copier. Ça exige l'Automatisation, refusée pour une app launchd. Tout passe par **CGEvent natif** (`post_cmd_key`, `post_key`), qui ne demande que l'Accessibilité.
- **TOUJOURS `encoding='utf-8'`** sur les `open()` de fichiers texte. Lancé par macOS, Python n'a pas de locale UTF-8 et retombe sur ASCII → `UnicodeDecodeError` sur le moindre accent, qui tuait le thread d'init → modèle jamais chargé. Bug le plus vicieux de la session.
- **Permissions TCC** : l'app a besoin de **Accessibilité** (collage + capture) ET **Surveillance des entrées** (capture clavier globale) ET **Micro**. Les deux premières ne mordent qu'**au redémarrage de l'app** après avoir coché. Grâce au bundle signé, la ligne dans Réglages s'appelle bien **« Murmure »** (et plus « python3.11 »).
- **Hook BlackHole** : `audio-switch.sh` est lancé au login par `~/Library/LaunchAgents/com.mardoukhaev.blackhole-audio.plist`. NE PAS casser.
- **Modèles dans `~/.cache/huggingface/`** (gitignored, hors bundle). turbo via repo `mobiuslabsgmbh/faster-whisper-large-v3-turbo`. Un nouveau modèle doit être téléchargé une fois SANS `local_files_only` avant de pouvoir servir.
- **Sample rate 16kHz mono** obligatoire pour Whisper.
- **Micro Continuité iPhone** : démarrage à FROID ~3,5s (connexion sans fil), puis ~170ms à chaud. La dictée push-to-talk ratait (« Pas de parole détectée ») car le micro se réveillait après le relâchement. Fix : `warm_mic()` pré-chauffe le micro choisi en arrière-plan (à la sélection + au démarrage de l'app). S'il se rendort après inactivité, la 1re dictée suivante peut rater (limite acceptée).
- **Fuite de F5 dans le terminal** : le raccourci F5 (bouton souris Logi) fuit dans le terminal sous forme de `5~` (code d'échappement). Les moniteurs NSEvent ne peuvent pas avaler une touche. Fix : un **CGEventTap** (`_setup_f5_tap`) qui ne gère QUE F5 et le CONSOMME (return None). Garder la gestion des touches SYNCHRONE (un refactor en threads avait créé une course start/stop qui cassait la dictée). Repli : si le tap échoue, NSEvent gère F5 (il fuit alors). Karabiner ne peut PAS corriger ça : Logi injecte F5 au-dessus de lui.
- **Blocage « Enregistrement... ad vitam » (15 juin 2026).** Symptôme : intermittent, des sessions de 10h OK puis l'app reste coincée sur « Enregistrement... », plus rien ne part. Cause : la transition recording→transcription dépend de l'événement de RELÂCHEMENT de touche. `start_recording` faisait le travail média (pmset x2 timeout 1s + osascript mute) **de façon synchrone dans le callback clavier** ; ce bloc ne s'active que **si un son joue** (`audio_is_playing()`), d'où l'intermittence : Twitch/vidéo en cours → callback lent → macOS désactive le CGEventTap F5 par timeout → le keyUp F5 n'est plus livré (et le repli NSEvent F5 est coupé quand le tap existe) → bloqué. Double fix : (1) **cause supprimée** : le travail média est sorti dans un thread de fond auto-nettoyant (`_handle_media_for_recording`, rétablit le son quand `state != 1`) → callback clavier instantané, plus de timeout de tap, et pas de race start/stop (rien à annuler dans `_hotkey_up`) ; (2) **watchdog** dans `sync_window` (`_recording_watchdog`) comme filet. PIÈGE : **`CGEventSourceKeyState` ne voit PAS le F5 du bouton souris Logi** (injecté en logiciel → toujours lu "relâché"). Si on poll F5, le watchdog coupe la dictée au bout de ~0,8s (« marche une demi-seconde »). Donc : on poll l'état physique UNIQUEMENT pour Option droite (kc 61, vrai modificateur, fiable) ; pour F5 on ne se fie qu'à un garde-fou de durée (`MAX_RECORD_SEC` = 120s). La source est taguée dans `_hotkey_down("opt"|"f5")`.
- **Commandes en terminal** : Whisper formate « claude » en « Claude. » (majuscule + point), ce qui casse la commande. Fix : dans un terminal (`is_terminal_app`), on retire la ponctuation finale de Whisper AVANT les commandes vocales (pour épargner les « point » volontaires) et on force la minuscule initiale. Pas de ponctuation auto dans les terminaux.

## Build du bundle

```bash
cd ~/Library/Application\ Support/Murmure
./venv/bin/python3 make_icon.py          # si l'icône change
# régénérer Murmure.icns depuis icon_1024.png (iconset + iconutil)
./venv/bin/python3 setup.py py2app -A     # build mode alias (signé ad-hoc auto)
cp -R dist/Murmure.app /Applications/      # installer
# puis re-cocher Murmure dans Accessibilité + Surveillance des entrées si l'identité change
```

## Lancement (dev)

```bash
./run.sh                        # lance via le venv, sans Terminal persistant si besoin
open /Applications/Murmure.app  # usage normal
```

## État

Outil quotidien de Valentin. Pas open source, pas distribué.
Refonte majeure 13 juin 2026 : sortie de pynput/osascript, fenêtre native, icône, bundle signé, déplacement hors Bureau.
