#!/usr/bin/env python3
"""
mur-mur — Menu Bar App
Dictée vocale locale via Whisper, icône micro dans la barre de menu.
"""

import re
import json
import subprocess
import threading
import time
import tempfile
import os
import wave
import signal

import numpy as np
import sounddevice as sd
import pyperclip
import rumps
from faster_whisper import WhisperModel

import objc
from Foundation import NSObject, NSMakeRect, NSBundle
from AppKit import (
    NSApplication, NSApplicationActivationPolicyRegular,
    NSWindow, NSWindowStyleMaskTitled, NSWindowStyleMaskClosable,
    NSWindowStyleMaskMiniaturizable, NSBackingStoreBuffered,
    NSView, NSTextField, NSButton, NSPopUpButton, NSBox,
    NSFont, NSColor, NSBezelStyleRounded, NSImage,
    NSEvent, NSEventMaskKeyDown, NSEventMaskKeyUp, NSEventMaskFlagsChanged,
    NSEventTypeKeyDown, NSEventTypeKeyUp, NSEventTypeFlagsChanged,
    NSEventModifierFlagOption, NSEventModifierFlagCommand, NSEventModifierFlagShift,
    NSWorkspace, NSSystemDefined,
)
from Quartz import (
    CGEventCreateKeyboardEvent, CGEventPost, CGEventSetFlags,
    kCGEventFlagMaskCommand, kCGHIDEventTap,
    CGEventTapCreate, CGEventTapEnable, CGEventMaskBit,
    kCGSessionEventTap, kCGHeadInsertEventTap, kCGEventTapOptionDefault,
    kCGEventKeyDown, kCGEventKeyUp,
    kCGEventTapDisabledByTimeout, kCGEventTapDisabledByUserInput,
    CGEventGetIntegerValueField, kCGKeyboardEventKeycode, kCGKeyboardEventAutorepeat,
    CFMachPortCreateRunLoopSource, CFRunLoopGetCurrent, CFRunLoopAddSource,
    kCFRunLoopCommonModes,
    CGEventSourceKeyState, kCGEventSourceStateCombinedSessionState,
)

# Codes touches virtuelles macOS
KEY_V = 9
KEY_C = 8
KEY_Z = 6
KEY_DELETE = 51


def post_cmd_key(keycode):
    """Envoie Cmd+<touche> en natif (CGEvent). Une seule permission requise :
    Accessibilité. Remplace osascript→System Events (qui exigeait en plus
    l'Automatisation, refusée pour une app lancée par launchd)."""
    down = CGEventCreateKeyboardEvent(None, keycode, True)
    CGEventSetFlags(down, kCGEventFlagMaskCommand)
    CGEventPost(kCGHIDEventTap, down)
    up = CGEventCreateKeyboardEvent(None, keycode, False)
    CGEventSetFlags(up, kCGEventFlagMaskCommand)
    CGEventPost(kCGHIDEventTap, up)


NX_KEYTYPE_PLAY = 16


def audio_is_playing():
    """True si un son sort vraiment en ce moment (coreaudiod tient une
    assertion d'énergie quand l'audio est rendu). Permet de ne mettre en
    pause QUE si ça joue : une vidéo déjà en pause n'est pas réveillée."""
    try:
        out = subprocess.run(["pmset", "-g", "assertions"],
                             capture_output=True, text=True, timeout=1).stdout
        for line in out.splitlines():
            low = line.lower()
            if "coreaudiod" in low and "preventuseridlesleep" in low:
                return True
        return False
    except Exception:
        return False


def media_play_pause():
    """Envoie la touche média Lecture/Pause du Mac (événement système).
    Met en pause / reprend YouTube, Spotify, Music, etc."""
    for down in (True, False):
        flags = 0xa00 if down else 0xb00
        data1 = (NX_KEYTYPE_PLAY << 16) | ((0xa if down else 0xb) << 8)
        ev = NSEvent.otherEventWithType_location_modifierFlags_timestamp_windowNumber_context_subtype_data1_data2_(
            NSSystemDefined, (0, 0), flags, 0, 0, None, 8, data1, -1)
        CGEventPost(kCGHIDEventTap, ev.CGEvent())


def count_audio_sources():
    """Nombre de flux audio actifs. coreaudiod tient une assertion
    'context.preventuseridlesleep' PAR source qui joue. Sert au mode Auto :
    1 source -> pause, plusieurs -> mute."""
    try:
        out = subprocess.run(["pmset", "-g", "assertions"],
                             capture_output=True, text=True, timeout=1).stdout
        n = sum(1 for line in out.splitlines()
                if "coreaudiod" in line.lower()
                and "preventuseridlesleep" in line.lower())
        return n
    except Exception:
        return 1


def set_muted(value):
    """Coupe (True) ou remet (False) le son de sortie du Mac."""
    subprocess.run(["osascript", "-e",
                    "set volume output muted " + ("true" if value else "false")],
                   capture_output=True)


def is_muted():
    try:
        r = subprocess.run(["osascript", "-e",
                            "output muted of (get volume settings)"],
                           capture_output=True, text=True, timeout=1)
        return "true" in r.stdout.lower()
    except Exception:
        return False


def post_key(keycode):
    """Envoie une touche simple (sans modificateur) en natif (CGEvent)."""
    down = CGEventCreateKeyboardEvent(None, keycode, True)
    CGEventPost(kCGHIDEventTap, down)
    up = CGEventCreateKeyboardEvent(None, keycode, False)
    CGEventPost(kCGHIDEventTap, up)

# --- Paths ---
APP_DIR = os.path.dirname(os.path.abspath(__file__))
DICT_FILE = os.path.join(APP_DIR, "dictionnaire.txt")
CORRECTIONS_FILE = os.path.join(APP_DIR, "corrections.txt")
CONFIG_FILE = os.path.join(APP_DIR, "config.json")


def load_config():
    """Réglages persistés (modèle, langue, micro, mode média)."""
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(data):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

# --- Config ---
MODELS = ("small", "medium", "large-v3-turbo")
MODEL_SIZE = "large-v3-turbo"
LANGUAGE = "fr"
LANGUAGES = ("fr", "en", None)  # None = détection auto
DEFAULT_MIC = "Micro MacBook Pro"
MEDIA_MODES = ("auto", "pause", "mute", "off")
SAMPLE_RATE = 16000
VAD_THRESHOLD = 0.01
VAD_MIN_SPEECH_SEC = 0.3
DOUBLE_TAP_SEC = 0.5
PASTE_GAP_SEC = 10
MAX_RECORD_SEC = 120  # garde-fou ultime : stoppe une dictée anormalement longue

# --- Sounds ---
SND_START = "/System/Library/Sounds/Tink.aiff"
SND_STOP = "/System/Library/Sounds/Pop.aiff"
SND_ERROR = "/System/Library/Sounds/Basso.aiff"
SND_UNDO = "/System/Library/Sounds/Funk.aiff"
SND_VOLUME = "0.15"

# --- Icons ---
ICON_RECORDING = "🔴"
ICON_TRANSCRIBING = "⏳"

# --- Commandes vocales ---
VOICE_COMMANDS = {
    "nouvelle ligne": "\n",
    "retour à la ligne": "\n",
    "à la ligne": "\n",
    "point": ".",
    "virgule": ",",
    "point d'interrogation": "?",
    "point d'exclamation": "!",
    "deux points": ":",
    "point-virgule": ";",
    "ouvrir les guillemets": "«\u202f",
    "fermer les guillemets": "\u202f»",
    "ouvrir parenthèse": "(",
    "fermer parenthèse": ")",
    "effacer": "",  # handled specially
}


def icon_for_model(model_size):
    if model_size == "small":
        tag = "S"
    elif model_size == "medium":
        tag = "M"
    else:
        tag = "L"  # large-v3-turbo
    return f"🎙{tag}"


def apply_voice_commands(text):
    for cmd, replacement in VOICE_COMMANDS.items():
        if cmd == "effacer":
            continue
        text = re.sub(
            re.escape(cmd),
            replacement,
            text,
            flags=re.IGNORECASE
        )
    # "effacer" → remove last word before the command
    text = re.sub(r'\S+\s+effacer', '', text, flags=re.IGNORECASE)
    text = re.sub(r'^effacer$', '', text, flags=re.IGNORECASE)
    return text.strip()


def auto_punctuation(text):
    if not text:
        return text
    # Majuscule en début de texte
    text = text[0].upper() + text[1:]
    # Majuscule après . ! ?
    text = re.sub(r'([.!?])\s+(\w)', lambda m: m.group(1) + " " + m.group(2).upper(), text)
    # Point final si pas de ponctuation à la fin
    if text and text[-1] not in ".!?,;:»)":
        text += "."
    return text


# Périphériques virtuels/loopback à NE PAS proposer comme micro (ils captent
# le son système ou sont des agrégats, pas ta voix).
_NON_MIC = ("blackhole", "aggregate", "agrégé", "agrege", "multi-output",
            "sortie multiple", "soundflower", "loopback", "sortie audio")


def list_input_devices():
    """Noms des VRAIS micros disponibles (exclut BlackHole, agrégés, etc.)."""
    seen, names = set(), []
    try:
        for d in sd.query_devices():
            name = d.get('name', '')
            if d.get('max_input_channels', 0) <= 0 or name in seen:
                continue
            if any(x in name.lower() for x in _NON_MIC):
                continue
            seen.add(name)
            names.append(name)
    except Exception:
        pass
    return names


def load_dictionary(language="fr"):
    words = []
    if os.path.exists(DICT_FILE):
        with open(DICT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    words.append(line)
    if language == "fr":
        base, label = "Conversation en français.", "Mots importants"
    elif language == "en":
        base, label = "Conversation in English.", "Important words"
    else:  # auto
        base, label = "", "Mots importants"
    if words:
        sep = " " if base else ""
        base += f"{sep}{label}: " + ", ".join(words) + "."
    return base


def load_corrections():
    corrections = {}
    if os.path.exists(CORRECTIONS_FILE):
        with open(CORRECTIONS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and ' -> ' in line:
                    wrong, right = line.split(' -> ', 1)
                    corrections[wrong.strip().lower()] = right.strip()
    return corrections


def apply_corrections(text, corrections):
    for wrong, right in corrections.items():
        text = re.sub(r'\b' + re.escape(wrong) + r'\b', right, text, flags=re.IGNORECASE)
    return text


def play_sound(sound_path):
    subprocess.Popen(
        ["afplay", "-v", SND_VOLUME, sound_path],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )


def trim_silence(audio, threshold=VAD_THRESHOLD, chunk_size=1600):
    start = 0
    for i in range(0, len(audio), chunk_size):
        chunk = audio[i:i + chunk_size]
        if np.sqrt(np.mean(chunk ** 2)) > threshold:
            start = max(0, i - chunk_size)
            break
    else:
        return np.array([], dtype=np.float32)
    end = len(audio)
    for i in range(len(audio), 0, -chunk_size):
        chunk = audio[max(0, i - chunk_size):i]
        if np.sqrt(np.mean(chunk ** 2)) > threshold:
            end = min(len(audio), i + chunk_size)
            break
    return audio[start:end]


def has_speech(audio, threshold=VAD_THRESHOLD, min_speech_sec=VAD_MIN_SPEECH_SEC):
    if len(audio) == 0:
        return False
    chunk_size = 1600
    speech_chunks = 0
    for i in range(0, len(audio), chunk_size):
        chunk = audio[i:i + chunk_size]
        if np.sqrt(np.mean(chunk ** 2)) > threshold:
            speech_chunks += 1
    return (speech_chunks * chunk_size / SAMPLE_RATE) >= min_speech_sec


def get_frontmost_app():
    """Nom de l'app au premier plan, en natif (NSWorkspace, zéro permission)."""
    try:
        app = NSWorkspace.sharedWorkspace().frontmostApplication()
        return app.localizedName() if app is not None else ""
    except Exception:
        return ""


_TERMINALS = ("Terminal", "iTerm2", "iTerm", "Warp", "Alacritty", "kitty",
              "WezTerm", "Ghostty", "Hyper", "Tabby", "rio")


def is_terminal_app(name):
    return name in _TERMINALS


# --- Fenêtre native (AppKit) ---
def _label(text, x, y, w, h, size=13, bold=False, color=None, align_right=False):
    f = NSTextField.alloc().initWithFrame_(NSMakeRect(x, y, w, h))
    f.setStringValue_(text)
    f.setBezeled_(False)
    f.setDrawsBackground_(False)
    f.setEditable_(False)
    f.setSelectable_(False)
    f.setFont_(NSFont.boldSystemFontOfSize_(size) if bold else NSFont.systemFontOfSize_(size))
    if color is not None:
        f.setTextColor_(color)
    if align_right:
        f.setAlignment_(2)  # NSTextAlignmentRight
    return f


def _button(title, x, y, w, h, target, action):
    b = NSButton.alloc().initWithFrame_(NSMakeRect(x, y, w, h))
    b.setTitle_(title)
    b.setBezelStyle_(NSBezelStyleRounded)
    b.setTarget_(target)
    b.setAction_(action)
    return b


class WindowActions(NSObject):
    """Cible Objective-C pour les boutons / popup de la fenêtre."""
    def initWithApp_(self, app):
        self = objc.super(WindowActions, self).init()
        if self is None:
            return None
        self.app = app
        return self

    def openDict_(self, sender):
        self.app.edit_dict(None)

    def openCorrections_(self, sender):
        self.app.edit_corrections(None)

    def reload_(self, sender):
        self.app.reload_dict(None)

    def toggleListening_(self, sender):
        self.app.toggle_listening(None)

    def quit_(self, sender):
        self.app.quit_app(None)

    def modelChanged_(self, sender):
        size = sender.titleOfSelectedItem()
        self.app.switch_to_model(size)

    def micChanged_(self, sender):
        self.app.set_mic(sender.titleOfSelectedItem())


class MurMur(rumps.App):
    def __init__(self):
        # Force le nom affiché (barre de menu / dock) à "Murmure" au lieu
        # de "Python", même lancé via l'interpréteur.
        try:
            _bundle = NSBundle.mainBundle()
            if _bundle is not None:
                _info = _bundle.localizedInfoDictionary() or _bundle.infoDictionary()
                if _info is not None:
                    _info["CFBundleName"] = "Murmure"
        except Exception:
            pass

        # Réglages persistés (modèle, langue, micro, mode média)
        cfg = load_config()
        _model = cfg.get("model_size")
        _model = _model if _model in MODELS else MODEL_SIZE

        super().__init__(
            name="Murmure",
            title=icon_for_model(_model),
            quit_button=None
        )

        # State
        self.state = 0  # 0=idle, 1=recording, 2=transcribing
        self.state_lock = threading.Lock()
        self.audio_chunks = []
        self.stream = None
        self.model = None
        self.model_size = _model
        self.models_cache = {}
        self.initial_prompt = ""
        self._last_release_time = 0
        self._last_paste_time = 0
        self._last_pasted_text = ""
        self._last_lang = ""
        self._last_text = ""
        self.enabled = True  # écoute du micro active
        self._release_missed_ticks = 0  # filet anti-blocage "Enregistrement..."
        self._record_source = "opt"     # "opt" (Option droite) ou "f5" (souris Logi)
        self._record_start_time = 0.0

        # Fenêtre native
        self.window = None
        self._actions = None
        self._ui = {}            # refs vers les champs/boutons de la fenêtre
        self._ui_last_status = None
        self._ui_last_text = None
        self._ui_last_model = None
        self._ui_last_enabled = None

        # Menu items
        self.status_item = rumps.MenuItem("Prêt")
        self.status_item.set_callback(None)
        self.last_item = rumps.MenuItem("Dernière: —")
        self.last_item.set_callback(None)
        # Réglages depuis la config (sinon défauts ; mode média = mute par défaut)
        _lang = cfg.get("force_language", LANGUAGE)
        self.force_language = _lang if _lang in LANGUAGES else LANGUAGE
        self.mic_device = cfg.get("mic_device") or DEFAULT_MIC
        _mode = cfg.get("media_mode")
        self.media_mode = _mode if _mode in MEDIA_MODES else "mute"
        self.lang_item = rumps.MenuItem(
            "Langue: " + (self.force_language or "auto"), callback=self.cycle_language)
        self.model_menu_item = rumps.MenuItem(
            "Modèle: " + self.model_size, callback=self.switch_model)
        self.media_menu_item = rumps.MenuItem(
            "Média: " + self.media_mode, callback=self.cycle_media_mode)

        self.menu = [
            self.status_item,
            self.last_item,
            self.lang_item,
            None,  # separator
            rumps.MenuItem("Ouvrir la fenêtre", callback=self.open_window),
            rumps.MenuItem("Mettre l'écoute en pause", callback=self.toggle_listening),
            None,
            rumps.MenuItem("Éditer le dictionnaire", callback=self.edit_dict),
            rumps.MenuItem("Éditer les corrections", callback=self.edit_corrections),
            rumps.MenuItem("Recharger le dictionnaire", callback=self.reload_dict),
            None,
            self.model_menu_item,
            self.media_menu_item,
            None,
            rumps.MenuItem("Quitter", callback=self.quit_app),
        ]

        # Sync fenêtre <-> état (sur le thread principal, donc thread-safe)
        self.sync_timer = rumps.Timer(self.sync_window, 0.4)
        self.sync_timer.start()

        # Load model in background
        threading.Thread(target=self._init, daemon=True).start()

    def _init(self):
        self.kill_other_instances()
        self.initial_prompt = load_dictionary(self.force_language)
        self.corrections = load_corrections()
        self.status_item.title = "Chargement du modèle..."
        self.model = WhisperModel(self.model_size, device="cpu", compute_type="int8", local_files_only=True)
        self.models_cache[self.model_size] = self.model
        self.status_item.title = "Prêt"
        self.title = icon_for_model(self.model_size)
        # Pré-chauffe le micro enregistré (utile si c'est le micro iPhone)
        self.warm_mic()
        # Les raccourcis (NSEvent) sont installés sur le thread principal
        # depuis sync_window, pas ici (thread secondaire interdit pour AppKit).

    def kill_other_instances(self):
        pass

    # --- Fenêtre native ---
    def build_window(self):
        if self.window is not None:
            return
        self._actions = WindowActions.alloc().initWithApp_(self)

        W, H = 360, 520
        style = (NSWindowStyleMaskTitled | NSWindowStyleMaskClosable
                 | NSWindowStyleMaskMiniaturizable)
        win = NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
            NSMakeRect(0, 0, W, H), style, NSBackingStoreBuffered, False)
        win.setTitle_("Murmure")
        win.setReleasedWhenClosed_(False)
        win.center()

        content = win.contentView()
        gray = NSColor.secondaryLabelColor()

        # Titre + pastille de statut
        content.addSubview_(_label("🎙  Murmure", 20, H - 50, 240, 30, size=20, bold=True))
        dot = _label("●", W - 50, H - 48, 30, 26, size=20, align_right=True)
        dot.setTextColor_(NSColor.systemGreenColor())
        content.addSubview_(dot)

        # Statut
        status = _label("Démarrage...", 20, H - 86, W - 40, 22, size=13)
        content.addSubview_(status)

        # Modèle
        content.addSubview_(_label("Modèle", 20, H - 128, 70, 24, size=13, color=gray))
        popup = NSPopUpButton.alloc().initWithFrame_pullsDown_(
            NSMakeRect(92, H - 132, 168, 28), False)
        popup.addItemsWithTitles_(list(MODELS))
        popup.selectItemWithTitle_(self.model_size)
        popup.setTarget_(self._actions)
        popup.setAction_("modelChanged:")
        content.addSubview_(popup)

        # Micro
        content.addSubview_(_label("Micro", 20, H - 168, 70, 24, size=13, color=gray))
        mic_popup = NSPopUpButton.alloc().initWithFrame_pullsDown_(
            NSMakeRect(92, H - 172, 228, 28), False)
        mics = list_input_devices()
        mic_popup.addItemsWithTitles_(mics)
        if self.mic_device in mics:
            mic_popup.selectItemWithTitle_(self.mic_device)
        elif mics:
            self.mic_device = mics[0]
            mic_popup.selectItemWithTitle_(mics[0])
        mic_popup.setTarget_(self._actions)
        mic_popup.setAction_("micChanged:")
        content.addSubview_(mic_popup)

        # Séparateur
        box = NSBox.alloc().initWithFrame_(NSMakeRect(20, H - 200, W - 40, 1))
        box.setBoxType_(2)  # NSBoxSeparator
        content.addSubview_(box)

        # Dernière dictée
        content.addSubview_(_label("Dernière dictée", 20, H - 228, W - 40, 20, size=12, bold=True, color=gray))
        last = NSTextField.alloc().initWithFrame_(NSMakeRect(20, H - 330, W - 40, 94))
        last.setBezeled_(True)
        last.setDrawsBackground_(True)
        last.setEditable_(False)
        last.setSelectable_(True)
        last.setFont_(NSFont.systemFontOfSize_(13))
        last.setStringValue_("—")
        last.cell().setWraps_(True)
        content.addSubview_(last)

        # Boutons
        content.addSubview_(_button("Dictionnaire", 20, 150, 155, 30, self._actions, "openDict:"))
        content.addSubview_(_button("Corrections", 185, 150, 155, 30, self._actions, "openCorrections:"))
        content.addSubview_(_button("Recharger le dictionnaire", 20, 114, 320, 30, self._actions, "reload:"))
        toggle = _button("Mettre l'écoute en pause", 20, 78, 320, 30, self._actions, "toggleListening:")
        content.addSubview_(toggle)
        content.addSubview_(_button("Quitter Murmure", 20, 42, 320, 30, self._actions, "quit:"))

        # Astuce
        content.addSubview_(_label(
            "Maintiens Option droite (ou F5) et parle.",
            20, 12, W - 40, 22, size=11, color=gray))

        self.window = win
        self._ui = {"dot": dot, "status": status, "popup": popup,
                    "last": last, "toggle": toggle}

    def open_window(self, _):
        self.build_window()
        self.window.makeKeyAndOrderFront_(None)
        NSApplication.sharedApplication().activateIgnoringOtherApps_(True)

    def sync_window(self, _):
        # Premier tick (thread principal) : icône dock + ouverture auto
        if not getattr(self, "_started", False):
            self._started = True
            if os.environ.get("MURMURE_DOCK", "1") == "1":
                NSApplication.sharedApplication().setActivationPolicy_(
                    NSApplicationActivationPolicyRegular)
            # Icône du dock
            icon_path = os.path.join(APP_DIR, "icon_1024.png")
            if os.path.exists(icon_path):
                img = NSImage.alloc().initWithContentsOfFile_(icon_path)
                if img is not None:
                    NSApplication.sharedApplication().setApplicationIconImage_(img)
            self.setup_hotkeys()
            self.open_window(None)
            return

        # Filet de sécurité anti-blocage (tourne même fenêtre masquée).
        self._recording_watchdog()

        if self.window is None or not self.window.isVisible():
            return

        ui = self._ui

        # Statut
        if self.enabled:
            status_txt = self.status_item.title
        else:
            status_txt = "En pause"
        if status_txt != self._ui_last_status:
            ui["status"].setStringValue_("Statut : " + status_txt)
            self._ui_last_status = status_txt

        # Pastille de couleur
        if not self.enabled:
            ui["dot"].setTextColor_(NSColor.systemGrayColor())
        elif self.state == 1:
            ui["dot"].setTextColor_(NSColor.systemRedColor())
        elif self.state == 2:
            ui["dot"].setTextColor_(NSColor.systemOrangeColor())
        else:
            ui["dot"].setTextColor_(NSColor.systemGreenColor())

        # Dernière dictée
        txt = self._last_text or "—"
        if txt != self._ui_last_text:
            ui["last"].setStringValue_(txt)
            self._ui_last_text = txt

        # Modèle
        if self.model_size != self._ui_last_model:
            ui["popup"].selectItemWithTitle_(self.model_size)
            self._ui_last_model = self.model_size

        # Libellé bouton pause
        if self.enabled != self._ui_last_enabled:
            ui["toggle"].setTitle_(
                "Mettre l'écoute en pause" if self.enabled else "Reprendre l'écoute")
            self._ui_last_enabled = self.enabled

    def _recording_watchdog(self):
        """Anti-blocage "Enregistrement... ad vitam".

        La transition recording -> transcription dépend de l'événement de
        RELÂCHEMENT de la touche, que macOS peut perdre.

        Deux filets selon la source :
        - Option droite (vrai modificateur) : on lit son état PHYSIQUE via
          CGEventSourceKeyState (fiable). Si on enregistre alors qu'elle n'est
          plus tenue sur 2 ticks (~0,8s), on stoppe nous-mêmes.
        - F5 (bouton souris Logi) : injecté en LOGICIEL, son état clavier
          n'est PAS lisible (CGEventSourceKeyState le voit toujours "relâché").
          On ne peut donc pas tester "tenu" -> on ne se fie qu'au garde-fou de
          durée. (Le vrai fix du blocage F5 est ailleurs : le travail média
          sorti du callback empêche le CGEventTap de timeouter.)
        Dans tous les cas, l'audio capté est transcrit : rien n'est perdu."""
        if self.state != 1:
            self._release_missed_ticks = 0
            return
        # Garde-fou ultime, indépendant de la touche.
        if self._record_start_time and \
                (time.time() - self._record_start_time) > MAX_RECORD_SEC:
            self._release_missed_ticks = 0
            self._hotkey_up()
            return
        if self._record_source != "opt":
            return  # F5 : pas de poll d'état fiable, on laisse le garde-fou
        held = CGEventSourceKeyState(
            kCGEventSourceStateCombinedSessionState, self.KC_RIGHT_OPTION)
        if held:
            self._release_missed_ticks = 0
            return
        self._release_missed_ticks += 1
        if self._release_missed_ticks >= 2:
            self._release_missed_ticks = 0
            self._hotkey_up()

    def toggle_listening(self, _):
        self.enabled = not self.enabled
        play_sound(SND_STOP if self.enabled else SND_UNDO)
        # Met à jour le libellé du menu bar
        try:
            self.menu["Mettre l'écoute en pause"].title = (
                "Mettre l'écoute en pause" if self.enabled else "Reprendre l'écoute")
        except KeyError:
            try:
                self.menu["Reprendre l'écoute"].title = (
                    "Mettre l'écoute en pause" if self.enabled else "Reprendre l'écoute")
            except KeyError:
                pass

    def switch_to_model(self, size):
        if size not in MODELS or size == self.model_size:
            return
        def do_switch():
            if size in self.models_cache:
                self.model = self.models_cache[size]
            else:
                self.model = WhisperModel(size, device="cpu", compute_type="int8", local_files_only=True)
                self.models_cache[size] = self.model
            self.model_size = size
            self.title = icon_for_model(size)
            self.model_menu_item.title = f"Modèle: {size}"
            self.save_settings()
            play_sound(SND_STOP)
        threading.Thread(target=do_switch, daemon=True).start()


    # --- Recording ---
    def _handle_media_for_recording(self):
        """Coupe le son ambiant pendant la dictée puis le rétablit, dans un
        thread de fond (les appels pmset/osascript sont lents : hors du
        callback clavier, ils ne peuvent plus faire timeout le CGEventTap).

        Auto-nettoyant : il rétablit le son dès que l'enregistrement s'arrête
        (state != 1), qu'on relâche la touche normalement OU que le watchdog
        débloque une dictée coincée. Rien à annuler ailleurs -> pas de race."""
        if self.media_mode == "off" or not audio_is_playing():
            return
        mode = self.media_mode
        if mode == "auto":
            mode = "mute" if count_audio_sources() >= 2 else "pause"
        action = None
        if mode == "pause":
            media_play_pause()
            action = "pause"
        elif mode == "mute" and not is_muted():
            set_muted(True)
            action = "mute"
        if action is None:
            return
        # Attend la fin de l'enregistrement (relâchement OU watchdog), puis
        # rétablit l'état du son. Borne de sécurité : 5 min max.
        for _ in range(6000):
            if self.state != 1:
                break
            time.sleep(0.05)
        if action == "pause":
            media_play_pause()
        elif action == "mute":
            set_muted(False)

    def start_recording(self):
        is_double_tap = (time.time() - self._last_release_time) < DOUBLE_TAP_SEC

        with self.state_lock:
            if self.state != 0:
                return
            self.state = 1

        if is_double_tap:
            self.undo_last_paste()

        # Coupe le son ambiant le temps de la dictée (selon le mode), dans un
        # THREAD de fond : ces appels (pmset x2, osascript) sont lents et,
        # exécutés dans le callback clavier, faisaient timeout le CGEventTap
        # F5 -> macOS désactivait le tap -> le relâchement était perdu ->
        # blocage "Enregistrement... ad vitam" (typiquement quand Twitch joue).
        # Le thread rétablit le son tout seul à la fin de l'enregistrement,
        # donc aucune annulation à coordonner dans _hotkey_up (pas de race).
        threading.Thread(target=self._handle_media_for_recording,
                         daemon=True).start()

        self.audio_chunks = []
        play_sound(SND_START)
        self.title = ICON_RECORDING
        self.status_item.title = "Enregistrement..."

        def callback(indata, frames, time_info, status):
            if self.state == 1:
                self.audio_chunks.append(indata.copy())

        try:
            self.stream = sd.InputStream(
                samplerate=SAMPLE_RATE, channels=1, dtype="float32",
                device=self.mic_device,
                callback=callback
            )
            self.stream.start()
        except Exception:
            # Micro choisi indisponible → repli sur le micro système par défaut
            self.stream = sd.InputStream(
                samplerate=SAMPLE_RATE, channels=1, dtype="float32",
                device=None,
                callback=callback
            )
            self.stream.start()

    def stop_and_transcribe(self):
        with self.state_lock:
            if self.state != 1:
                return
            self.state = 2

        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None

        play_sound(SND_STOP)
        self.title = ICON_TRANSCRIBING
        self.status_item.title = "Transcription..."

        if not self.audio_chunks:
            self.title = icon_for_model(self.model_size)
            self.status_item.title = "Prêt"
            with self.state_lock:
                self.state = 0
            return

        audio = np.concatenate(self.audio_chunks, axis=0).flatten()
        audio = trim_silence(audio)

        if not has_speech(audio):
            self.title = icon_for_model(self.model_size)
            self.status_item.title = "Pas de parole détectée"
            with self.state_lock:
                self.state = 0
            return

        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        with wave.open(tmp.name, 'w') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes((audio * 32767).astype(np.int16).tobytes())

        segments, info = self.model.transcribe(
            tmp.name, language=self.force_language, initial_prompt=self.initial_prompt
        )
        text = " ".join(seg.text for seg in segments).strip()
        os.unlink(tmp.name)

        is_term = is_terminal_app(get_frontmost_app())
        if text and is_term:
            # Commande brute : retire la ponctuation finale que Whisper ajoute
            # tout seul (avant les commandes vocales, pour ne pas effacer un
            # « point » volontaire type « cd .. »).
            text = text.rstrip(" .!?…").strip()

        if text:
            text = apply_voice_commands(text)
        if text and self.corrections:
            text = apply_corrections(text, self.corrections)
        if text:
            if is_term:
                # Pas de majuscule auto : commande en minuscule.
                text = text[0].lower() + text[1:]
            else:
                text = auto_punctuation(text)

        if text:
            self._last_lang = getattr(info, 'language', '?')
            self._last_text = text

            # Truncate for menu display
            display = text[:50] + "..." if len(text) > 50 else text
            self.last_item.title = f"Dernière: {display}"

            # Spacing
            if (time.time() - self._last_paste_time) <= PASTE_GAP_SEC:
                text = " " + text
            self._last_paste_time = time.time()
            self._last_pasted_text = text

            # Paste (natif : clipboard + Cmd+V via CGEvent)
            pyperclip.copy(text)
            time.sleep(0.1)
            post_cmd_key(KEY_V)
            self.status_item.title = "Prêt"
        else:
            self.status_item.title = "Rien détecté"

        self.title = icon_for_model(self.model_size)
        time.sleep(0.5)
        with self.state_lock:
            self.state = 0

    def undo_last_paste(self):
        if self._last_pasted_text:
            play_sound(SND_UNDO)
            app = get_frontmost_app()
            if is_terminal_app(app):
                # Effacer caractère par caractère (Cmd+Z peu fiable en terminal)
                for _ in range(len(self._last_pasted_text)):
                    post_key(KEY_DELETE)
            else:
                post_cmd_key(KEY_Z)
            self._last_pasted_text = ""
            time.sleep(0.15)

    # --- Keyboard (NSEvent natif, thread principal) ---
    KC_RIGHT_OPTION = 61
    KC_F5 = 96
    KC_D = 2

    def setup_hotkeys(self):
        """Installe les moniteurs clavier natifs sur le thread principal.
        Remplace pynput (qui interrogeait une API clavier hors thread
        principal → crash SIGTRAP sur macOS récent)."""
        mask = (NSEventMaskKeyDown | NSEventMaskKeyUp | NSEventMaskFlagsChanged)
        # Événements destinés aux AUTRES apps (cas normal : on dicte ailleurs)
        self._global_monitor = NSEvent.addGlobalMonitorForEventsMatchingMask_handler_(
            mask, self._on_event_global)
        # Événements destinés à notre propre fenêtre (doit retourner l'event)
        self._local_monitor = NSEvent.addLocalMonitorForEventsMatchingMask_handler_(
            mask, self._on_event_local)
        # En PLUS : un event tap qui ne fait QU'avaler F5 (pour qu'il ne fuie
        # pas dans le terminal sous forme de '5~'). Si le tap échoue, les
        # moniteurs NSEvent ci-dessus gèrent F5 quand même (il fuit alors).
        self._setup_f5_tap()

    def _setup_f5_tap(self):
        try:
            mask = (CGEventMaskBit(kCGEventKeyDown)
                    | CGEventMaskBit(kCGEventKeyUp))
            tap = CGEventTapCreate(
                kCGSessionEventTap, kCGHeadInsertEventTap,
                kCGEventTapOptionDefault, mask, self._f5_tap_callback, None)
            if not tap:
                return
            self._f5_tap = tap
            self._f5_tap_source = CFMachPortCreateRunLoopSource(None, tap, 0)
            CFRunLoopAddSource(CFRunLoopGetCurrent(), self._f5_tap_source,
                               kCFRunLoopCommonModes)
            CGEventTapEnable(tap, True)
        except Exception:
            pass

    def _f5_tap_callback(self, proxy, etype, event, refcon):
        # NE GÈRE QUE F5. Tout le reste passe inchangé (return event).
        try:
            if etype in (kCGEventTapDisabledByTimeout,
                         kCGEventTapDisabledByUserInput):
                CGEventTapEnable(self._f5_tap, True)
                return event
            kc = CGEventGetIntegerValueField(event, kCGKeyboardEventKeycode)
            if kc != self.KC_F5:
                return event  # toutes les autres touches : intactes
            if etype == kCGEventKeyDown:
                if not CGEventGetIntegerValueField(
                        event, kCGKeyboardEventAutorepeat):
                    self._hotkey_down("f5")
                return None   # AVALE F5 → ne fuit plus dans le terminal
            if etype == kCGEventKeyUp:
                self._hotkey_up()
                return None
            return event
        except Exception:
            return event

    def _on_event_global(self, event):
        self._handle_event(event)

    def _on_event_local(self, event):
        self._handle_event(event)
        return event

    def _handle_event(self, event):
        try:
            etype = event.type()
            kc = event.keyCode()
            flags = event.modifierFlags()

            if etype == NSEventTypeFlagsChanged:
                if kc == self.KC_RIGHT_OPTION:
                    if flags & NSEventModifierFlagOption:
                        self._hotkey_down("opt")
                    else:
                        self._hotkey_up()

            elif etype == NSEventTypeKeyDown:
                # F5 géré ici seulement si l'event tap n'est pas actif
                if (kc == self.KC_F5 and not event.isARepeat()
                        and not getattr(self, "_f5_tap", None)):
                    self._hotkey_down("f5")
                elif (kc == self.KC_D
                      and (flags & NSEventModifierFlagCommand)
                      and (flags & NSEventModifierFlagShift)):
                    threading.Thread(target=self.add_selection_to_dict,
                                     daemon=True).start()

            elif etype == NSEventTypeKeyUp:
                if kc == self.KC_F5 and not getattr(self, "_f5_tap", None):
                    self._hotkey_up()
        except Exception:
            pass

    def _hotkey_down(self, source="opt"):
        if self.enabled and self.model is not None:
            self._record_source = source
            self._record_start_time = time.time()
            self._release_missed_ticks = 0
            self.start_recording()

    def _hotkey_up(self):
        self._last_release_time = time.time()
        # Le son ambiant est rétabli par _handle_media_for_recording dès que
        # l'enregistrement s'arrête : rien à annuler ici.
        threading.Thread(target=self.stop_and_transcribe, daemon=True).start()

    def add_selection_to_dict(self):
        """Grab selected text and add it to the dictionary."""
        # Copy selection to clipboard (natif : Cmd+C via CGEvent)
        old_clipboard = pyperclip.paste()
        post_cmd_key(KEY_C)
        time.sleep(0.2)
        word = pyperclip.paste().strip()

        # Restore old clipboard
        if old_clipboard:
            pyperclip.copy(old_clipboard)

        if not word or len(word) > 50:
            rumps.notification("mur-mur", "Erreur", "Sélectionne un mot avant Cmd+Shift+D")
            return

        # Check if already in dictionary
        existing = []
        if os.path.exists(DICT_FILE):
            with open(DICT_FILE, 'r', encoding='utf-8') as f:
                existing = [l.strip() for l in f.readlines()]

        if word in existing:
            rumps.notification("mur-mur", "Déjà dans le dictionnaire", word)
            return

        # Add to file
        with open(DICT_FILE, 'a', encoding='utf-8') as f:
            f.write(f"\n{word}")

        # Reload prompt
        self.initial_prompt = load_dictionary(self.force_language)
        play_sound(SND_STOP)
        rumps.notification("mur-mur", "Mot ajouté au dictionnaire", word)

    # --- Menu actions ---
    def edit_dict(self, _):
        subprocess.Popen(["open", "-e", DICT_FILE])

    def edit_corrections(self, _):
        subprocess.Popen(["open", "-e", CORRECTIONS_FILE])

    def reload_dict(self, _):
        self.initial_prompt = load_dictionary(self.force_language)
        self.corrections = load_corrections()
        rumps.notification(
            title="mur-mur",
            subtitle="Dictionnaire rechargé",
            message=f"{len(self.initial_prompt.split(', '))} mots chargés"
        )

    def switch_model(self, sender):
        i = MODELS.index(self.model_size) if self.model_size in MODELS else 0
        new_size = MODELS[(i + 1) % len(MODELS)]
        self.switch_to_model(new_size)

    def cycle_language(self, _):
        i = LANGUAGES.index(self.force_language) if self.force_language in LANGUAGES else 0
        self.force_language = LANGUAGES[(i + 1) % len(LANGUAGES)]
        self.lang_item.title = "Langue: " + (self.force_language or "auto")
        self.initial_prompt = load_dictionary(self.force_language)
        self.save_settings()
        play_sound(SND_STOP)

    def set_mic(self, name):
        if name:
            self.mic_device = name
            self.save_settings()
            self.warm_mic()

    def warm_mic(self):
        """Réveille le micro sélectionné en arrière-plan. Utile pour le micro
        Continuité de l'iPhone qui met ~3,5s à démarrer à froid : on absorbe ce
        délai ici, pour que la dictée suivante soit instantanée."""
        device = self.mic_device
        def warm():
            try:
                st = sd.InputStream(samplerate=SAMPLE_RATE, channels=1,
                                    dtype="float32", device=device,
                                    callback=lambda *a: None)
                st.start()
                time.sleep(0.3)
                st.stop()
                st.close()
            except Exception:
                pass
        threading.Thread(target=warm, daemon=True).start()

    def cycle_media_mode(self, sender):
        i = MEDIA_MODES.index(self.media_mode) if self.media_mode in MEDIA_MODES else 0
        self.media_mode = MEDIA_MODES[(i + 1) % len(MEDIA_MODES)]
        sender.title = "Média: " + self.media_mode
        self.save_settings()
        play_sound(SND_STOP)

    def save_settings(self):
        save_config({
            "model_size": self.model_size,
            "force_language": self.force_language,
            "mic_device": self.mic_device,
            "media_mode": self.media_mode,
        })

    def quit_app(self, _):
        rumps.quit_application()


if __name__ == "__main__":
    MurMur().run()
