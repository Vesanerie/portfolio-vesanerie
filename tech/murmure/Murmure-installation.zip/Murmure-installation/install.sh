#!/bin/bash
# Installation de Murmure (dictée vocale locale, Whisper) sur un Mac.
# Usage :  bash install.sh
# Idempotent : on peut le relancer sans risque, rien n'est supprimé
# (une ancienne install est mise de côté, jamais effacée).
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/Murmure"
PY_VERSION="3.11"

step() { printf "\n\033[1;34m==> %s\033[0m\n" "$1"; }
warn() { printf "\033[1;33m[!] %s\033[0m\n" "$1"; }
die()  { printf "\033[1;31m[x] %s\033[0m\n" "$1"; exit 1; }

# --- 0. Vérifs de base -------------------------------------------------------
step "Vérification du système"
[[ "$(uname)" == "Darwin" ]] || die "Ce script ne tourne que sur macOS."
echo "macOS $(sw_vers -productVersion) · $(uname -m)"
[[ "$(uname -m)" == "arm64" ]] || warn "Mac Intel détecté : ça doit marcher, mais la transcription sera nettement plus lente (préférer le modèle 'small')."

# --- 1. Homebrew + Python 3.11 ----------------------------------------------
step "Homebrew et Python $PY_VERSION"
if ! command -v brew >/dev/null 2>&1; then
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    [[ -x "$b" ]] && eval "$("$b" shellenv)" && break
  done
fi
command -v brew >/dev/null 2>&1 || die "Homebrew absent. L'installer d'abord (https://brew.sh) puis relancer ce script."

if ! brew list --versions python@$PY_VERSION >/dev/null 2>&1; then
  brew install python@$PY_VERSION
fi
PY="$(brew --prefix python@$PY_VERSION)/bin/python$PY_VERSION"
[[ -x "$PY" ]] || die "Python $PY_VERSION introuvable après installation ($PY)."
"$PY" --version

# --- 2. Copie du projet dans Application Support -----------------------------
# Jamais sur le Bureau / Documents / Téléchargements : macOS (TCC) bloque
# l'accès à ces dossiers pour une app lancée par le système.
step "Copie du projet vers $DEST"
if [[ -d "$DEST" && ! -f "$DEST/.murmure-install" ]]; then
  BAK="$DEST.ancien-$(date +%Y%m%d-%H%M%S)"
  warn "Un dossier Murmure existe déjà : mis de côté dans $BAK"
  mv "$DEST" "$BAK"
fi
mkdir -p "$DEST"
for f in app.py setup.py make_icon.py icon_1024.png Murmure.icns run.sh CLAUDE.md requirements.txt; do
  cp "$HERE/app/$f" "$DEST/"
done
# Dico et corrections : on ne réécrase pas ceux de l'utilisateur s'ils existent
for f in dictionnaire.txt corrections.txt; do
  [[ -f "$DEST/$f" ]] || cp "$HERE/app/$f" "$DEST/"
done
chmod +x "$DEST/run.sh"
touch "$DEST/.murmure-install"

# --- 3. Environnement Python -------------------------------------------------
step "Environnement Python (venv) + dépendances"
cd "$DEST"
[[ -x venv/bin/python3 ]] || "$PY" -m venv venv
./venv/bin/python3 -m pip install --upgrade pip >/dev/null
./venv/bin/python3 -m pip install -r requirements.txt

# --- 4. Modèle Whisper -------------------------------------------------------
# L'app charge les modèles en local_files_only : il faut les télécharger une fois.
step "Téléchargement du modèle Whisper large-v3-turbo (~1,5 Go, une seule fois)"
./venv/bin/python3 - <<'PY'
from faster_whisper import WhisperModel
WhisperModel("large-v3-turbo", device="cpu", compute_type="int8")
print("Modèle turbo prêt.")
PY
if [[ "${MURMURE_SMALL:-0}" == "1" ]]; then
  ./venv/bin/python3 -c 'from faster_whisper import WhisperModel; WhisperModel("small", device="cpu", compute_type="int8"); print("Modèle small prêt.")'
fi

# --- 5. Bundle Murmure.app ---------------------------------------------------
step "Construction de Murmure.app (py2app, mode alias) + signature ad-hoc"
rm -rf build dist 2>/dev/null || true
./venv/bin/python3 setup.py py2app -A >/dev/null
codesign --force --deep --sign - dist/Murmure.app

if [[ -d /Applications/Murmure.app ]]; then
  pkill -f "Murmure.app/Contents/MacOS/Murmure" 2>/dev/null || true
  OLD="$HOME/.Trash/Murmure-ancien-$(date +%Y%m%d-%H%M%S).app"
  warn "Ancienne /Applications/Murmure.app déplacée dans la Corbeille"
  mv /Applications/Murmure.app "$OLD"
fi
cp -R dist/Murmure.app /Applications/

# --- 6. Lancement ------------------------------------------------------------
step "Lancement"
open /Applications/Murmure.app

cat <<'EOF'

============================================================
 Murmure est installé. Il reste 3 permissions à donner À LA MAIN
 (macOS interdit de les cocher par script) :

 Réglages Système > Confidentialité et sécurité :
   1. Microphone              -> Murmure (la fenêtre s'affiche seule au 1er essai)
   2. Accessibilité           -> ajouter / cocher Murmure
   3. Surveillance des entrées -> ajouter / cocher Murmure

 PUIS QUITTER ET RELANCER Murmure (les permissions 2 et 3
 ne prennent effet qu'au redémarrage de l'app).

 Utilisation : maintenir Option DROITE, parler, relâcher.
 Le texte se colle tout seul là où est le curseur.
============================================================
EOF
