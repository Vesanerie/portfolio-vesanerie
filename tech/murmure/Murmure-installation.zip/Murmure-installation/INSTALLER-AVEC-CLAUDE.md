# Murmure · consignes d'installation pour Claude Code

> À l'humain : ouvre Claude Code dans ce dossier et dis-lui simplement
> « lis INSTALLER-AVEC-CLAUDE.md et installe Murmure ».

## C'est quoi

Murmure est une app macOS de **dictée vocale 100 % locale** (Whisper, rien ne part sur Internet).
On maintient **Option droite**, on parle, on relâche : le texte transcrit est collé tout seul dans l'app active.
Interface : icône dans la barre des menus + petite fenêtre native + icône dans le Dock.

Le code source est dans `app/`. Le fichier `app/CLAUDE.md` est le playbook technique complet
(architecture, pièges macOS déjà résolus). **Le lire avant de modifier quoi que ce soit dans `app.py`.**

## Prérequis

- macOS 11 ou plus, idéalement Apple Silicon (M1 et suivants). Sur Intel ça marche mais c'est lent.
- **Homebrew** installé (sinon : https://brew.sh, l'installation demande le mot de passe de l'utilisateur, à lui de le taper).
- ~2 Go d'espace libre (venv ~250 Mo + modèle Whisper turbo ~1,5 Go).
- Une connexion Internet pour l'installation seulement.

## Installation (Claude, fais ça)

1. Lancer le script, depuis ce dossier :
   ```bash
   bash install.sh
   ```
   Il fait tout dans l'ordre : Python 3.11 via Homebrew, copie du projet dans
   `~/Library/Application Support/Murmure/`, venv + dépendances, téléchargement du modèle,
   construction de `/Applications/Murmure.app` (py2app mode alias + signature ad-hoc), lancement.
   Il est relançable sans risque et ne supprime rien (anciennes versions mises de côté).
   Option : `MURMURE_SMALL=1 bash install.sh` télécharge aussi le modèle `small` (plus rapide, moins précis, utile sur Intel ou petit Mac).

2. **Guider l'utilisateur pour les permissions** (impossible à automatiser, macOS l'interdit) :
   Réglages Système > Confidentialité et sécurité :
   - **Microphone** : Murmure (la demande apparaît seule à la première dictée)
   - **Accessibilité** : bouton +, choisir `/Applications/Murmure.app`, cocher
   - **Surveillance des entrées** : pareil
   Puis **quitter Murmure (menu bar > Quitter) et le relancer** : Accessibilité et Surveillance
   des entrées ne prennent effet qu'au redémarrage de l'app.
   Raccourci pour ouvrir les bons panneaux :
   ```bash
   open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
   open "x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent"
   ```

3. **Choisir le micro** dans la fenêtre Murmure. Le défaut est « Micro MacBook Pro » ;
   sur un autre modèle (MacBook Air, iMac, micro USB…) l'app prend le premier micro trouvé,
   ce qui peut être un iPhone en Continuité. Faire choisir le bon dans la liste déroulante
   (le choix est mémorisé dans `config.json`).

4. **Test** : ouvrir Notes, maintenir Option droite, dire une phrase, relâcher.
   Le texte doit apparaître en 1 à 3 secondes.

5. Optionnel : lancer Murmure au démarrage :
   Réglages Système > Général > Ouverture > ajouter `/Applications/Murmure.app`.

## Dépannage (pièges connus)

| Symptôme | Cause / remède |
|---|---|
| Rien ne se passe quand on appuie sur Option droite | Accessibilité ou Surveillance des entrées pas cochée, OU app pas relancée après cochage. |
| Dans Réglages, l'app apparaît comme « python3.11 » | L'app a été lancée via `run.sh` au lieu de `/Applications/Murmure.app`. Toujours lancer le bundle. |
| « Pas de parole détectée » | Mauvais micro sélectionné, ou permission Micro refusée. |
| Le modèle ne charge jamais | Il n'a pas été téléchargé (l'app est en `local_files_only`). Relancer l'étape 4 du script. |
| Après un rebuild du bundle, plus rien ne marche | L'identité du binaire a changé : décocher puis recocher Murmure dans Accessibilité et Surveillance des entrées, relancer. |
| Logs | Lancer `cd ~/Library/Application\ Support/Murmure && ./run.sh` dans un terminal pour voir les erreurs. |

Ne **jamais** déplacer le projet sur le Bureau, Documents ou Téléchargements : macOS bloque l'accès
à ces dossiers pour une app lancée par le système (venv illisible, app muette).

## Fonctions utiles à expliquer à l'utilisateur

- **Option droite** maintenue = dictée. **Double-tap Option droite** = annuler la dernière dictée.
- **Cmd+Shift+D** sur un mot sélectionné = l'ajouter au dictionnaire (meilleure reconnaissance des noms propres).
- `dictionnaire.txt` : vocabulaire perso. `corrections.txt` : remplacements auto (`mal_entendu -> correct`).
  Les deux s'éditent depuis le menu bar, puis « Recharger le dictionnaire ».
- Menu bar : langue (fr / en / auto), modèle (small / medium / turbo), gestion du son pendant la dictée
  (mute par défaut : coupe le son de l'ordi pendant qu'on parle pour que le micro ne capte pas la vidéo en cours).
- Commandes vocales : « nouvelle ligne », « point », « virgule »…
- La touche F5 sert aussi de raccourci (prévu pour un bouton de souris Logitech) ; sans effet gênant sinon.
